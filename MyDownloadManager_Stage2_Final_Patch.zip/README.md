# My Download Manager — Stage 2: Real Download Engine

A Windows desktop application built with Python 3.13, PySide6, and HTTPX.

Stage 2 upgrades the desktop foundation with a fully functional HTTP/HTTPS streaming download engine, a sequential queue manager, real-time download metrics, robust error handling, graceful application shutdown, and thread-safe Qt GUI updates.

---

## What Works in Stage 2

### 1. Real HTTP & HTTPS Downloading
- **Direct Downloads:** Downloads actual files over HTTP and HTTPS protocols.
- **Low Memory Streaming:** Streams large files in chunks (64 KB) directly to disk without loading entire files into memory.
- **HTTP Redirects:** Seamlessly follows 301, 302, 307, and 308 redirects to destination files.
- **Smart Filename Detection Priority:**
  1. `Content-Disposition` filename from the final HTTP response (including RFC 5987 / RFC 6266 UTF-8 encoded names).
  2. Explicit user-provided filename override (if supplied).
  3. Filename extracted from the final redirected response URL.
  4. Fallback filename.
  *(Automatically extracted URL names are never treated as user overrides).*
- **File Size & Unknown Size Support:** Detects total size via `Content-Length`. Graciously handles chunked or unknown file sizes with live byte counts and activity indicators.

### 2. File Safety & Windows Compatibility
- **Temporary `.part` Files:** Files stream into `.part` files during download.
- **Safe No-Overwrite Finalisation:** Completed files are moved using a non-destructive atomic rename strategy. If another file exists or is created concurrently, safe sequential numbering (`file (1).ext`, `file (2).ext`) is automatically used without overwriting existing data.
- **Windows Filename Sanitization:** Eliminates invalid characters (`< > : " / \ | ? *`), handles Windows reserved device names (`CON`, `PRN`, `AUX`, `NUL`, `COM1-9`, `LPT1-9`), and trims trailing dots/spaces.
- **Safe Cleanup:** Incomplete `.part` files are automatically removed upon user cancellation, permanent failure, or application shutdown.

### 3. Real-Time Progress & UI Feedback
- **Live Progress Bars:** Styled `QProgressBar` for each download in the table.
- **Download Metrics:**
  - Real-time download speed in `KB/s` or `MB/s` (smoothed moving average).
  - Estimated remaining time (ETA).
  - Downloaded and total file sizes (e.g. `12.50 MB / 50.00 MB`).
- **Responsive UI:** Background downloads execute inside dedicated `QThread` workers with throttled progress signals (~12 Hz) to prevent UI freezing or event loop congestion.
- **Accurate Dashboard Metrics:** Metric cards for `TOTAL DOWNLOADS`, `DOWNLOADING`, `COMPLETED`, and `QUEUED` update in real time. Items in `Retrying` state are accurately counted as active downloads.
- **Color-Coded Status Badges:** Visual indication for `Queued` (yellow), `Downloading` (blue), `Completed` (green), `Failed` (red), `Cancelled` (muted), and `Retrying` (orange).

### 4. Sequential Queue Management & Graceful Shutdown
- **Sequential Queue:** Only one download executes at a time. When one completes, fails, or is cancelled, the next queued item starts automatically.
- **Graceful Application Shutdown:** When closing the application, active downloads are immediately cancelled, active network streams are aborted, and running `QThreads` terminate cleanly before application destruction. If a worker outlasts the shutdown timeout, the application rejects the close event, restores the UI, shows a clear warning, and preserves all thread/worker references without destroying a running `QThread`. Users can retry closing after the worker completes.
- **Controls:**
  - **Start Queued:** Start processing queued downloads sequentially.
  - **Cancel Active:** Gracefully cancel the active download and clean up temporary files.
  - **Right-Click Context Menu:** Start, Cancel, Open Containing Folder, Open File, Copy Download URL, or Remove item.
  - **Double-Click Row:** Opens completed files or destination folders directly in Windows Explorer.

### 5. Error Handling & Precise Retry Classification
- **Automatic Retry for Transient Errors:** Transient network errors (timeouts, network drop, connection reset) and server-side errors (HTTP 500, 502, 503, 504) are automatically retried up to 3 attempts with progressive backoff.
- **Immediate Failure for Permanent Errors:** Client errors (HTTP 400, 401, 403, 404, invalid scheme) fail immediately without retrying.
- **Immediate Failure for Local Disk Errors:** Permission errors, disk-full (`ENOSPC`), and local I/O failures fail immediately without wasteful retries.
- **Clear Error Tooltips:** Detailed diagnostics are visible on hover in the interface.

---

## Project Structure

```text
MyDownloadManager/
├── app.py                      # Application entry point
├── requirements.txt            # Python dependencies
├── README.md                   # Project documentation
│
├── mdm/
│   ├── __init__.py             # Package marker
│   ├── main_window.py          # PySide6 dark UI & main application window
│   ├── downloader.py           # Core HTTPX streaming downloader & retry engine
│   ├── download_worker.py      # QThread QObject worker with throttled signals
│   ├── queue_manager.py        # Sequential queue controller & metrics coordinator
│   ├── utils.py                # Filename sanitization, formatting & path resolution
│   ├── browser_host.py         # Browser host integration (future stage placeholder)
│   ├── database.py             # SQLite persistence (future stage placeholder)
│   ├── scheduler.py            # Download scheduler (future stage placeholder)
│   ├── segment_manager.py      # Segmented downloader (Stage 3 placeholder)
│   └── settings.py             # Settings configuration (future stage placeholder)
│
└── tests/
    └── test_downloader.py      # Comprehensive 26-test automated suite
```

---

## Run on Windows PowerShell

### 1. Activate Virtual Environment
Open PowerShell in the project directory and activate the existing virtual environment:

```powershell
.venv\Scripts\Activate.ps1
```

### 2. Install Requirements (if needed)
```powershell
python -m pip install -r requirements.txt
```

### 3. Run the Application
```powershell
python app.py
```

---

## Running the Automated Test Suite

The test suite covers small/large file downloads, redirected filenames, Content-Disposition priority, user explicit overrides, cancellation, graceful shutdown, shutdown timeout reference preservation (QueueManager), close-event rejection and retry dialog (MainWindow), disk permission and disk-full errors, permanent 404s, transient 503 retries, dashboard retry metrics, Windows filename sanitization (including compound names like `CON.foo.bar`), collision-safe finalisation under race conditions, format utilities, and Qt UI integration.

Execute the tests using:

```powershell
python -m unittest discover -s tests -v
```

All 26 tests execute self-contained, socket-free, and pass completely.

---

## Known Limitations (Stage 2)

The following capabilities are deliberately excluded in Stage 2 and will be implemented in subsequent development stages:
- **Pause & Resume:** Resuming partial downloads using HTTP `Range` headers is reserved for a future stage.
- **Segmented Multi-Part Downloading:** Multi-connection accelerated downloading will be implemented in Stage 3.
- **SQLite Database Persistence:** History and queue persistence across app restarts is reserved for a future stage.
- **Browser Extension Integration:** Native messaging host for Chrome/Edge integration will be implemented in a future stage.
- **Bandwidth Scheduling:** Speed limits and scheduling rules will be introduced in a future stage.
